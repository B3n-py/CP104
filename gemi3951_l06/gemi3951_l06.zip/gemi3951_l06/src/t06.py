"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Benjamin Geminiuc
ID:      169033951
Email:   gemi3951@mylaurier.ca
__updated__ = "2022-10-25"
-------------------------------------------------------
"""

from functions import draw_triangle

draw_triangle(6, '$')
