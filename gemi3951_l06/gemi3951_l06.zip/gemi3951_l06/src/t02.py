"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Benjamin Geminiuc
ID:      169033951
Email:   gemi3951@mylaurier.ca
__updated__ = "2022-10-25"
-------------------------------------------------------
"""

from functions import sum_odd


print(sum_odd(123))
