"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Benjamin Geminiuc
ID:      169033951
Email:   gemi3951@mylaurier.ca
__updated__ = "2022-10-28"
-------------------------------------------------------
"""

from functions import bottles_of_beer


bottles_of_beer(4)
