"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Benjamin Geminiuc
ID:      169033951
Email:   gemi3951@mylaurier.ca
__updated__ = "2022-10-28"
-------------------------------------------------------
"""

from functions import retirement

retirement(25, 56000, 1.5)
